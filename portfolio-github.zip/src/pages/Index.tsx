import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import ExperienceSection from "@/components/ExperienceSection";
import ProjectsSection from "@/components/ProjectsSection";
import AcademicsSection from "@/components/AcademicsSection";
import ActivitiesSection from "@/components/ActivitiesSection";
import BlogSection from "@/components/BlogSection";
import ReferencesSection from "@/components/ReferencesSection";
import ContactSection from "@/components/ContactSection";

export default function Index() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection />
      <ExperienceSection />
      <ProjectsSection />
      <AcademicsSection />
      <ActivitiesSection />
      <BlogSection />
      <ReferencesSection />
      <ContactSection />
    </div>
  );
}