import { BarChart3, Globe, LineChart, Search, X } from "lucide-react";
import { useState } from "react";

const projects = [
  {
    title: "North Africa Omnichannel Strategy Optimization",
    description:
      "Designed and analyzed omnichannel marketing initiatives to improve customer engagement and campaign performance across North Africa.",
    details:
      "Led the design and analysis of omnichannel marketing strategies across North Africa for Pfizer. Analyzed data by channel and product to identify the most effective touchpoints, shared actionable insights with cross-functional teams, and optimized campaign performance. This initiative resulted in improved customer engagement and more efficient resource allocation across digital and traditional channels.",
    tech: ["Power BI", "Excel", "Veeva PromoMats", "Salesforce CRM"],
    icon: Globe,
  },
  {
    title: "Pfizer Pro Digital Platform Launch",
    description:
      "Supported the launch and deployment of Pfizer Pro by coordinating content, agencies, and go-live activities.",
    details:
      "Managed the end-to-end launch of Pfizer Pro, a digital platform for healthcare professionals, from content preparation to go-live coordination with external agencies. Also supported the deployment of OncoMate and WhatsApp Business platforms. Ensured compliance with global and local regulatory requirements while maintaining tight project timelines.",
    tech: ["Veeva PromoMats", "Adobe Creative Suite", "Salesforce CRM"],
    icon: LineChart,
  },
  {
    title: "Marketing KPI Dashboard",
    description:
      "Built dashboards to monitor campaign performance and commercial KPIs, enabling data-driven decisions.",
    details:
      "Developed comprehensive Power BI dashboards to track marketing performance metrics including budgets, ROI, campaign effectiveness, and commercial KPIs. These dashboards provided real-time visibility into marketing investments and enabled the team to make data-driven decisions, optimize spending, and produce actionable recommendations for stakeholders.",
    tech: ["Power BI", "SQL", "Excel"],
    icon: BarChart3,
  },
  {
    title: "Competitive Intelligence & Market Insights Framework",
    description:
      "Developed reporting frameworks to identify market opportunities and support strategic decision-making.",
    details:
      "Created a structured competitive intelligence framework for the North Africa pharmaceutical market. Conducted market research, industry analyses, and competitor monitoring to identify trends and growth opportunities. The framework provided regular insights reports that supported strategic decision-making and go-to-market planning.",
    tech: ["Power BI", "Python", "Excel"],
    icon: Search,
  },
];

export default function ProjectsSection() {
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  return (
    <section id="projects" className="py-20 bg-[#faf9f7]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-[#1a1f36] mb-4 text-center">
          Featured Projects
        </h2>
        <p className="text-center text-[#1a1f36]/60 mb-12 max-w-2xl mx-auto">
          Key projects showcasing my expertise in product marketing, business
          intelligence, and data-driven strategy. Click any project to learn more.
        </p>

        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((project, index) => {
            const IconComponent = project.icon;
            return (
              <button
                key={index}
                onClick={() => setSelectedProject(index)}
                className="group bg-white rounded-xl border border-gray-100 p-6 hover:shadow-lg hover:border-[#e8634f]/20 transition-all duration-300 cursor-pointer text-left w-full"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-[#e8634f]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#e8634f]/20 transition-colors">
                    <IconComponent className="w-6 h-6 text-[#e8634f]" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-[#1a1f36] mb-2 group-hover:text-[#e8634f] transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-[#1a1f36]/60 leading-relaxed mb-4">
                      {project.description}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {project.tech.map((t, i) => (
                        <span
                          key={i}
                          className="text-xs px-2.5 py-1 rounded-full bg-[#1a1f36]/5 text-[#1a1f36]/70 font-medium"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                    <p className="text-xs text-[#e8634f] mt-3 font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                      Click to view details →
                    </p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Project Detail Modal */}
      {selectedProject !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={() => setSelectedProject(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto p-8 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-[#e8634f]/10 flex items-center justify-center">
                  {(() => {
                    const IconComponent = projects[selectedProject].icon;
                    return <IconComponent className="w-6 h-6 text-[#e8634f]" />;
                  })()}
                </div>
                <h3 className="text-xl font-bold text-[#1a1f36]">
                  {projects[selectedProject].title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedProject(null)}
                className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4 text-[#1a1f36]" />
              </button>
            </div>

            <p className="text-[#1a1f36]/70 leading-relaxed mb-6">
              {projects[selectedProject].details}
            </p>

            <div>
              <h4 className="text-sm font-semibold text-[#1a1f36] mb-3">
                Technologies & Tools
              </h4>
              <div className="flex flex-wrap gap-2">
                {projects[selectedProject].tech.map((t, i) => (
                  <span
                    key={i}
                    className="text-sm px-3 py-1.5 rounded-lg bg-[#e8634f]/10 text-[#e8634f] font-medium"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}