import { Linkedin, Github, Mail, MapPin } from "lucide-react";

export default function HeroSection() {
  return (
    <section
      id="about"
      className="min-h-screen flex items-center pt-16 pb-20 bg-[#faf9f7]"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid md:grid-cols-5 gap-12 items-center">
          {/* Profile photo - LEFT side (up position) */}
          <div className="md:col-span-2 flex justify-center animate-fade-in-delay">
            <div className="relative">
              <div className="w-64 h-64 sm:w-72 sm:h-72 lg:w-80 lg:h-80 rounded-full overflow-hidden border-4 border-[#e8634f]/20 shadow-xl">
                <img
                  src="/assets/profile.png"
                  alt="Nour Gnich"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-2 -right-2 w-20 h-20 bg-[#e8634f]/10 rounded-full blur-xl" />
              <div className="absolute -top-4 -left-4 w-16 h-16 bg-[#f4a4a0]/20 rounded-full blur-lg" />
            </div>
          </div>

          {/* Text content - RIGHT side */}
          <div className="md:col-span-3 animate-slide-up">
            <p className="text-sm font-medium uppercase tracking-wider text-[#e8634f] mb-3">
              Meet Me
            </p>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-[#1a1f36] mb-4 leading-tight">
              Nour Gnich
            </h1>
            <p className="text-lg sm:text-xl text-[#e8634f] font-medium mb-6">
              Product Marketing Associate Manager{" "}
              <span className="text-[#1a1f36]/40">|</span> Business Intelligence
              Analyst
            </p>
            <p className="text-base text-[#1a1f36]/70 leading-relaxed mb-6 max-w-xl">
              Product Marketing Specialist with 3 years of experience in the
              pharmaceutical industry, specialised in go-to-market strategies,
              product positioning, and cross-functional collaboration.
              Complemented by a specialization in Data Science & Business
              Intelligence, enabling data and analytical insights to optimize
              commercial strategies, support operational excellence, and enhance
              customer experience.
            </p>

            {/* Location & availability */}
            <div className="flex flex-wrap items-center gap-4 mb-6 text-sm text-[#1a1f36]/60">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#e8634f]" />
                Île de France, France
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-medium">
                Open to remote work
              </span>
            </div>

            {/* Social links */}
            <div className="flex items-center gap-4 mb-8">
              <a
                href="https://www.linkedin.com/in/nourgnich"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#1a1f36] flex items-center justify-center hover:bg-[#e8634f] transition-colors cursor-pointer"
              >
                <Linkedin className="w-4 h-4 text-white" />
              </a>
              <a
                href="https://github.com/nourgn076-cmyk"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#1a1f36] flex items-center justify-center hover:bg-[#e8634f] transition-colors cursor-pointer"
              >
                <Github className="w-4 h-4 text-white" />
              </a>
              <a
                href="mailto:nourgn076@gmail.com"
                className="w-10 h-10 rounded-full bg-[#1a1f36] flex items-center justify-center hover:bg-[#e8634f] transition-colors cursor-pointer"
              >
                <Mail className="w-4 h-4 text-white" />
              </a>
            </div>

            {/* Quote */}
            <blockquote className="border-l-4 border-[#e8634f] pl-4 italic text-[#1a1f36]/60 text-sm">
              "Without data, you're just another person with an opinion."
              <span className="block mt-1 not-italic font-medium">
                — W. Edwards Deming
              </span>
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}