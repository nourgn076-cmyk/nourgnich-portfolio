import { Award, TrendingUp, Rocket, BookOpen, Sparkles } from "lucide-react";

const activities = [
  {
    title: "3+ Years in Pharmaceutical Industry",
    description:
      "Extensive experience working with global pharmaceutical companies (Pfizer) on marketing and business intelligence initiatives across North Africa.",
    icon: TrendingUp,
  },
  {
    title: "North African Market Specialist",
    description:
      "Specialized expertise in pharmaceutical markets across North Africa, including go-to-market strategies, product positioning, and regulatory compliance.",
    icon: Award,
  },
  {
    title: "Digital Transformation Leader",
    description:
      "Led cross-functional marketing and digital transformation initiatives including Pfizer Pro, OncoMate, and WhatsApp Business platform launches.",
    icon: Rocket,
  },
  {
    title: "Data Science & BI Specialization",
    description:
      "Currently pursuing an advanced specialization in Data Science & Business Intelligence at EDC Paris Business School (Programme Grande École).",
    icon: BookOpen,
  },
];

const interests = [
  "Gym",
  "Playing Piano",
  "Discovering New Cultures",
  "Data & AI Innovation",
  "Continuous Learning",
  "International Networking",
];

export default function ActivitiesSection() {
  return (
    <section id="activities" className="py-20 bg-[#1a1f36]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-12 text-center">
          Activities & Achievements
        </h2>

        <div className="grid sm:grid-cols-2 gap-6 mb-12">
          {activities.map((activity, index) => {
            const IconComponent = activity.icon;
            return (
              <div
                key={index}
                className="bg-white/5 border border-white/10 rounded-xl p-6"
              >
                <div className="w-12 h-12 rounded-lg bg-[#e8634f]/20 flex items-center justify-center mb-4">
                  <IconComponent className="w-6 h-6 text-[#e8634f]" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  {activity.title}
                </h3>
                <p className="text-sm text-white/60 leading-relaxed">
                  {activity.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Interests */}
        <div className="text-center">
          <h3 className="text-lg font-semibold text-white/80 mb-4 flex items-center justify-center gap-2">
            <Sparkles className="w-4 h-4 text-[#e8634f]" />
            Interests
          </h3>
          <div className="flex flex-wrap justify-center gap-3">
            {interests.map((interest, index) => (
              <span
                key={index}
                className="px-4 py-2 rounded-full bg-white/10 border border-white/10 text-sm text-white/70 font-medium"
              >
                {interest}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}