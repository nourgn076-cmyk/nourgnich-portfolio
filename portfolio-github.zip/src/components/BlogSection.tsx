import { BookOpen, Calendar, ArrowRight, X, GraduationCap } from "lucide-react";
import { useState } from "react";

const blogPosts = [
  {
    title: "How AI-Driven Business Intelligence Supports Forecasting, Customer Insights, and Marketing Strategic Decision-Making in Disrupted and Uncertain Environments",
    date: "May 2026",
    category: "Master Thesis",
    institution: "EDC Paris Business School – Programme Grande École",
    supervisor: "Galina Kondrateva",
    summary:
      "This master thesis analyses the role of AI-enabled Business Intelligence (BI) in facilitating strategic decision-making in forecasting, customer insights, and marketing in the context of disruptive and uncertain business environments.",
    content: `This study analyses the role of AI-enabled Business Intelligence (BI) in facilitating strategic decision-making in forecasting, customer insights, and marketing in the context of disruptive and uncertain business environments.

Research Context:
Recent shocks including the COVID-19 pandemic, geopolitical instability, inflation, and rapid technological change have exposed vulnerabilities in organisations whose marketing intelligence systems were designed for more stable conditions. Predictive models reliant on historical data have produced biased forecasts; customer segmentation has rapidly become obsolete; and traditional planning frameworks have provided limited guidance in novel, unpredictable contexts.

Central Research Question:
"How does AI-driven Business Intelligence support forecasting, customer insights, and marketing strategic decision-making in disrupted and uncertain business environments?"

Methodology:
The study followed a qualitative design, based on 10 semi-structured interviews with marketing experts and AI-BI practitioners from Tunisia, France, and the United Kingdom. Data were examined using reflective thematic analysis (Braun and Clarke, 2006). The study is underpinned by an interpretivist epistemology and a constructivist ontological perspective.

Theoretical Frameworks:
• Dynamic Capabilities Theory — AI-driven BI as enabling organisations to sense, seize, and reconfigure
• Resource-Based View (RBV) — Real advantage lies in unique organisational capabilities
• Kolbjørnsrud's (2024) Intelligent Organisation Framework — AI supports rather than replaces human judgment

Key Findings (Five Empirically Grounded Themes):

Theme 1: AI-BI under Disruption — From Predictive Failure to Real-Time Monitoring
AI-based BI enables marketing strategy under disruption by transferring value from prediction to real-time monitoring. Real-time monitoring capability proves more strategically valuable than predictive capability under disruption.

Theme 2: The Last-Mile Gap — Between AI-Generated Insight and Strategic Action
A persistent "last mile gap" was found as the main driver of value degradation between insight generation and strategic implementation.

Theme 3: AI-Enabled Marketing Leadership and Calibrated Trust
AI-driven marketing leadership characterised by "calibrated trust" was identified as a key mediating condition for successful AI-BI deployment.

Theme 4: Governance Architecture as the Enabling Condition of AI-BI Value
The enabling infrastructure was governance architecture — including model monitoring, human override systems, and escalation protocols.

Theme 5: Data Quality as the Binding Structural Constraint
Data quality was verified as a binding structural constraint that determines the ceiling of AI-BI value creation.

Contribution:
This work adds to the field by empirically separating monitoring and predictive functions under disruption, by establishing the last mile gap as a structural failing, and by presenting practitioner-level data on governance designs that enable AI-driven BI to be a true strategic asset.`,
    tags: ["AI-Driven BI", "Marketing Strategy", "Disruption", "Forecasting", "Customer Insights", "Governance", "Qualitative Research"],
    keywords: ["AI-driven Business Intelligence", "marketing strategic decision-making", "disruption", "forecasting", "client insights", "last-mile gap", "governance"],
  },
];

export default function BlogSection() {
  const [selectedPost, setSelectedPost] = useState<number | null>(null);

  return (
    <section id="blog" className="py-20 bg-[#faf9f7]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-[#1a1f36] mb-4 text-center">
          Research & Publications
        </h2>
        <p className="text-center text-[#1a1f36]/60 mb-12 max-w-2xl mx-auto">
          Academic research and thought leadership in AI-driven business
          intelligence and marketing strategy.
        </p>

        <div className="max-w-3xl mx-auto">
          {blogPosts.map((post, index) => (
            <button
              key={index}
              onClick={() => setSelectedPost(index)}
              className="w-full bg-white rounded-xl border border-gray-100 p-6 hover:shadow-lg hover:border-[#e8634f]/20 transition-all duration-300 cursor-pointer text-left group"
            >
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-xl bg-[#e8634f]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#e8634f]/20 transition-colors">
                  <GraduationCap className="w-7 h-7 text-[#e8634f]" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2 flex-wrap">
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#e8634f]/10 text-[#e8634f] font-medium">
                      {post.category}
                    </span>
                    <span className="text-xs text-[#1a1f36]/40 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {post.date}
                    </span>
                  </div>
                  <h3 className="text-base font-semibold text-[#1a1f36] mb-2 group-hover:text-[#e8634f] transition-colors leading-snug">
                    {post.title}
                  </h3>
                  <p className="text-xs text-[#1a1f36]/50 mb-2">
                    {post.institution} • Supervisor: {post.supervisor}
                  </p>
                  <p className="text-sm text-[#1a1f36]/60 leading-relaxed mb-3">
                    {post.summary}
                  </p>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {post.tags.slice(0, 5).map((tag, i) => (
                      <span
                        key={i}
                        className="text-xs px-2 py-0.5 rounded bg-[#1a1f36]/5 text-[#1a1f36]/60"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <span className="text-sm text-[#e8634f] font-medium flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    Read full summary <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Blog Post Modal */}
      {selectedPost !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={() => setSelectedPost(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-3xl w-full max-h-[85vh] overflow-y-auto p-8 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-start gap-3 flex-1">
                <div className="w-12 h-12 rounded-lg bg-[#e8634f]/10 flex items-center justify-center flex-shrink-0">
                  <GraduationCap className="w-6 h-6 text-[#e8634f]" />
                </div>
                <div>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#e8634f]/10 text-[#e8634f] font-medium">
                    {blogPosts[selectedPost].category}
                  </span>
                  <h3 className="text-lg font-bold text-[#1a1f36] mt-2 leading-snug">
                    {blogPosts[selectedPost].title}
                  </h3>
                  <p className="text-sm text-[#1a1f36]/50 mt-1">
                    {blogPosts[selectedPost].institution} • {blogPosts[selectedPost].date}
                  </p>
                  <p className="text-sm text-[#1a1f36]/50">
                    Supervisor: {blogPosts[selectedPost].supervisor}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPost(null)}
                className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors cursor-pointer flex-shrink-0 ml-4"
              >
                <X className="w-4 h-4 text-[#1a1f36]" />
              </button>
            </div>

            <div className="prose prose-sm max-w-none">
              {blogPosts[selectedPost].content.split("\n\n").map((paragraph, i) => (
                <p
                  key={i}
                  className="text-[#1a1f36]/70 leading-relaxed mb-4 whitespace-pre-line"
                >
                  {paragraph}
                </p>
              ))}
            </div>

            <div className="mt-6 pt-4 border-t border-gray-100">
              <h4 className="text-sm font-semibold text-[#1a1f36] mb-3">
                Keywords
              </h4>
              <div className="flex flex-wrap gap-2">
                {blogPosts[selectedPost].keywords.map((keyword, i) => (
                  <span
                    key={i}
                    className="text-sm px-3 py-1.5 rounded-lg bg-[#e8634f]/10 text-[#e8634f] font-medium"
                  >
                    {keyword}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}