import { Linkedin, UserCheck } from "lucide-react";

const references = [
  {
    name: "Lamyae Remmal",
    role: "Oncology Category Lead - North Africa",
    company: "Pfizer",
    linkedin: "https://www.linkedin.com/in/lamyae-remmal-pharmd-49b8985/",
  },
  {
    name: "Yasmine Sedrati",
    role: "Vaccines Category Lead North Africa",
    company: "Pfizer",
    linkedin: "https://www.linkedin.com/in/yasminesedrati/",
  },
  {
    name: "Youssra Aouida",
    role: "Oncology Country Brand Manager Morocco, Tunisia, and Libya",
    company: "Pfizer",
    linkedin: "https://www.linkedin.com/in/aouidayoussra/",
  },
];

export default function ReferencesSection() {
  return (
    <section id="references" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-[#1a1f36] mb-4 text-center">
          References
        </h2>
        <p className="text-center text-[#1a1f36]/60 mb-12 max-w-lg mx-auto">
          Professional references available upon request.
        </p>

        <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {references.map((ref, index) => (
            <div
              key={index}
              className="bg-[#faf9f7] rounded-xl border border-gray-100 p-5 text-center"
            >
              <div className="w-12 h-12 rounded-full bg-[#e8634f]/10 flex items-center justify-center mx-auto mb-4">
                <UserCheck className="w-5 h-5 text-[#e8634f]" />
              </div>
              <h3 className="text-base font-semibold text-[#1a1f36] mb-1">
                {ref.name}
              </h3>
              <p className="text-sm text-[#1a1f36]/60 mb-1">{ref.role}</p>
              <p className="text-xs text-[#e8634f] font-medium mb-3">
                {ref.company}
              </p>
              <a
                href={ref.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-medium text-[#1a1f36]/60 hover:text-[#e8634f] transition-colors"
              >
                <Linkedin className="w-3.5 h-3.5" />
                LinkedIn Profile
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}