import { Mail, Linkedin, Github, Globe, Send } from "lucide-react";
import { useState } from "react";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const mailtoLink = `mailto:nourgn076@gmail.com?subject=Message from ${formData.name}&body=${encodeURIComponent(formData.message)}%0A%0AFrom: ${formData.email}`;
    window.location.href = mailtoLink;
  };

  return (
    <section id="contact" className="py-20 bg-[#faf9f7]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-[#1a1f36] mb-4 text-center">
          Get in Touch
        </h2>
        <p className="text-center text-[#1a1f36]/60 mb-12 max-w-lg mx-auto">
          I'm always open to discussing new opportunities, collaborations, or
          just having a chat about marketing and data.
        </p>

        <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto">
          {/* Contact info */}
          <div className="space-y-6">
            <a
              href="mailto:nourgn076@gmail.com"
              className="flex items-center gap-4 group"
            >
              <div className="w-12 h-12 rounded-full bg-[#e8634f]/10 flex items-center justify-center group-hover:bg-[#e8634f]/20 transition-colors">
                <Mail className="w-5 h-5 text-[#e8634f]" />
              </div>
              <div>
                <p className="text-sm text-[#1a1f36]/50">Email</p>
                <p className="text-sm font-medium text-[#1a1f36] group-hover:text-[#e8634f] transition-colors">
                  nourgn076@gmail.com
                </p>
              </div>
            </a>

            <a
              href="https://www.linkedin.com/in/nourgnich"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 group"
            >
              <div className="w-12 h-12 rounded-full bg-[#e8634f]/10 flex items-center justify-center group-hover:bg-[#e8634f]/20 transition-colors">
                <Linkedin className="w-5 h-5 text-[#e8634f]" />
              </div>
              <div>
                <p className="text-sm text-[#1a1f36]/50">LinkedIn</p>
                <p className="text-sm font-medium text-[#1a1f36] group-hover:text-[#e8634f] transition-colors">
                  linkedin.com/in/nourgnich
                </p>
              </div>
            </a>

            <a
              href="https://github.com/nourgn076-cmyk"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 group"
            >
              <div className="w-12 h-12 rounded-full bg-[#e8634f]/10 flex items-center justify-center group-hover:bg-[#e8634f]/20 transition-colors">
                <Github className="w-5 h-5 text-[#e8634f]" />
              </div>
              <div>
                <p className="text-sm text-[#1a1f36]/50">GitHub</p>
                <p className="text-sm font-medium text-[#1a1f36] group-hover:text-[#e8634f] transition-colors">
                  github.com/nourgn076-cmyk
                </p>
              </div>
            </a>

            <a
              href="https://nourgn076-cmyk.github.io/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 group"
            >
              <div className="w-12 h-12 rounded-full bg-[#e8634f]/10 flex items-center justify-center group-hover:bg-[#e8634f]/20 transition-colors">
                <Globe className="w-5 h-5 text-[#e8634f]" />
              </div>
              <div>
                <p className="text-sm text-[#1a1f36]/50">Portfolio</p>
                <p className="text-sm font-medium text-[#1a1f36] group-hover:text-[#e8634f] transition-colors">
                  nourgn076-cmyk.github.io
                </p>
              </div>
            </a>
          </div>

          {/* Contact form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[#1a1f36]/70 mb-1">
                Your Name <span className="text-[#e8634f]">*</span>
              </label>
              <input
                type="text"
                placeholder="Enter your name"
                required
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                className="w-full px-4 py-3 rounded-lg border border-gray-200 bg-white text-sm text-[#1a1f36] placeholder:text-[#1a1f36]/40 focus:outline-none focus:ring-2 focus:ring-[#e8634f]/30 focus:border-[#e8634f] transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#1a1f36]/70 mb-1">
                Your Email <span className="text-[#e8634f]">*</span>
              </label>
              <input
                type="email"
                placeholder="Enter your email"
                required
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
                className="w-full px-4 py-3 rounded-lg border border-gray-200 bg-white text-sm text-[#1a1f36] placeholder:text-[#1a1f36]/40 focus:outline-none focus:ring-2 focus:ring-[#e8634f]/30 focus:border-[#e8634f] transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#1a1f36]/70 mb-1">
                Your Message <span className="text-[#e8634f]">*</span>
              </label>
              <textarea
                placeholder="Write your message here..."
                required
                rows={5}
                value={formData.message}
                onChange={(e) =>
                  setFormData({ ...formData, message: e.target.value })
                }
                className="w-full px-4 py-3 rounded-lg border border-gray-200 bg-white text-sm text-[#1a1f36] placeholder:text-[#1a1f36]/40 focus:outline-none focus:ring-2 focus:ring-[#e8634f]/30 focus:border-[#e8634f] transition-all resize-none"
              />
            </div>
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-[#e8634f] text-white font-medium text-sm hover:bg-[#d4553f] transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
              Send Message
            </button>
          </form>
        </div>

        {/* Footer */}
        <div className="mt-20 pt-8 border-t border-gray-200 text-center">
          <p className="text-sm text-[#1a1f36]/40">
            © {new Date().getFullYear()} Nour Gnich. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  );
}