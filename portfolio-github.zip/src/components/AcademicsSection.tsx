import { GraduationCap, Globe2, Calendar, MapPin } from "lucide-react";

const coreCompetencies = [
  "Product Marketing",
  "Go-to-Market Strategy",
  "Customer Engagement",
  "Product Positioning",
  "Product Launches",
  "Omnichannel Marketing",
  "Marketing Communications",
  "Content Development",
  "Sales Enablement",
  "Competitive Intelligence",
  "Market Research & Insights",
  "Marketing Analytics",
  "Cross-functional Collaboration",
  "Customer Experience",
  "Project Management",
  "Life Sciences",
  "Business Intelligence",
];

const technicalSkills = {
  "CRM & Marketing Platforms": ["Veeva PromoMats", "Salesforce CRM", "SAP Ariba"],
  "Data & Analytics": ["Power BI", "SQL", "Python", "Excel", "KPI Reporting"],
  "Project Management": ["Agile", "Scrum", "Jira", "Trello"],
  "Design": ["Adobe Creative Suite", "Canva"],
  "Version Control & Collaboration": ["Git", "GitHub"],
};

const education = [
  {
    degree: "M2 – Programme Grande École",
    specialization: "Data Science & Business Intelligence",
    school: "EDC Paris Business School",
    dates: "Sept. 2025 – Aug. 2026",
    location: "France",
  },
  {
    degree: "Master's in Communication and Future Marketing",
    specialization: "",
    school: "Global Business School Barcelona",
    dates: "Sept. 2020 – July 2021",
    location: "Spain",
  },
  {
    degree: "Bachelor's in Business Administration",
    specialization: "",
    school: "Mediterranean School of Business",
    dates: "Sept. 2016 – July 2019",
    location: "Tunisia",
  },
];

const languages = [
  { name: "English", level: "C2 (Mastery)" },
  { name: "French", level: "Bilingual" },
  { name: "Arabic", level: "Native" },
];

export default function AcademicsSection() {
  return (
    <section id="academics" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-[#1a1f36] mb-12 text-center">
          Skills & Education
        </h2>

        {/* Core Competencies */}
        <div className="mb-12">
          <h3 className="text-xl font-semibold text-[#1a1f36] mb-6">
            Core Competencies
          </h3>
          <div className="flex flex-wrap gap-2.5">
            {coreCompetencies.map((skill, index) => (
              <span
                key={index}
                className="px-3.5 py-2 rounded-lg bg-[#faf9f7] border border-gray-100 text-sm font-medium text-[#1a1f36]/80"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>

        {/* Technical Skills */}
        <div className="mb-12">
          <h3 className="text-xl font-semibold text-[#1a1f36] mb-6">
            Technical Skills
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(technicalSkills).map(([category, skills]) => (
              <div
                key={category}
                className="bg-[#faf9f7] rounded-lg p-4 border border-gray-100"
              >
                <h4 className="text-sm font-semibold text-[#e8634f] mb-2">
                  {category}
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {skills.map((skill, i) => (
                    <span
                      key={i}
                      className="text-xs px-2 py-1 rounded bg-white border border-gray-100 text-[#1a1f36]/70"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Education */}
          <div className="lg:col-span-3">
            <h3 className="text-xl font-semibold text-[#1a1f36] mb-6">
              Education
            </h3>
            <div className="space-y-5">
              {education.map((edu, index) => (
                <div
                  key={index}
                  className="bg-[#faf9f7] rounded-xl p-5 border border-gray-100"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-[#e8634f]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <GraduationCap className="w-5 h-5 text-[#e8634f]" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-base font-semibold text-[#1a1f36]">
                        {edu.degree}
                      </h4>
                      {edu.specialization && (
                        <p className="text-sm text-[#e8634f] font-medium mt-0.5">
                          Specialization: {edu.specialization}
                        </p>
                      )}
                      <p className="text-sm text-[#1a1f36]/70 font-medium mt-1">
                        {edu.school}
                      </p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-[#1a1f36]/50">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {edu.dates}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {edu.location}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Languages */}
          <div className="lg:col-span-2">
            <h3 className="text-xl font-semibold text-[#1a1f36] mb-6">
              Languages
            </h3>
            <div className="space-y-4">
              {languages.map((lang, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 bg-[#faf9f7] rounded-lg p-3 border border-gray-100"
                >
                  <div className="w-8 h-8 rounded-full bg-[#e8634f]/10 flex items-center justify-center">
                    <Globe2 className="w-4 h-4 text-[#e8634f]" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-[#1a1f36]">
                      {lang.name}
                    </p>
                    <p className="text-xs text-[#1a1f36]/50">{lang.level}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}