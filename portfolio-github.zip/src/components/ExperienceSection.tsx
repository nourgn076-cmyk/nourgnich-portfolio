import { Briefcase } from "lucide-react";

const experiences = [
  {
    company: "Lynxeo",
    role: "Marketing & Sales Analyst",
    dates: "Oct. 2025 – In Progress",
    type: "",
    description: [
      "Supporting marketing and sales strategies through market research, competitive intelligence, and commercial KPI monitoring.",
      "Coordinating events, developing sales collateral, and collaborating with cross-functional teams to drive business growth.",
    ],
  },
  {
    company: "Pfizer",
    role: "Junior Product Marketing Manager – North Africa Market",
    dates: "May 2022 – May 2025",
    type: "CDD",
    description: [
      "Managed product marketing initiatives including promotional materials, omnichannel strategy, and digital platform launches (Pfizer Pro, OncoMate) across North Africa.",
      "Tracked marketing performance, organized scientific events, and delivered data-driven recommendations to optimize campaign ROI.",
    ],
  },
  {
    company: "Maersk",
    role: "Customer Experience Specialist",
    dates: "Oct. 2021 – Apr. 2022",
    type: "CDI",
    description: [
      "Responded to customer requests via Case Management (Salesforce CRM).",
      "Created and managed customer satisfaction surveys; implemented best practices to optimize customer experience.",
    ],
  },
  {
    company: "Whirlpool",
    role: "Marketing Analyst",
    dates: "May 2020 – Aug. 2020",
    type: "Internship",
    description: [
      "Contributed to market studies and consumer behavior analysis.",
      "Performed statistical analyses and monitored competitor activities.",
    ],
  },
  {
    company: "Hôtel Sheraton Tunis",
    role: "Sales Representative",
    dates: "Jun. 2018 – Aug. 2018",
    type: "Internship",
    description: [
      "Learned hotel management strategies.",
      "Participated in sales calls.",
    ],
  },
];

export default function ExperienceSection() {
  return (
    <section id="experience" className="py-20 bg-[#1a1f36]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-12 text-center">
          Professional Experience
        </h2>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 md:left-1/2 md:-translate-x-px top-0 bottom-0 w-0.5 bg-[#e8634f]/30" />

          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <div
                key={index}
                className={`relative flex flex-col md:flex-row ${
                  index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                } items-start md:items-center gap-4 md:gap-8`}
              >
                {/* Timeline dot */}
                <div className="absolute left-4 md:left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-[#e8634f] border-2 border-[#1a1f36] z-10" />

                {/* Content card */}
                <div
                  className={`ml-10 md:ml-0 md:w-[45%] ${
                    index % 2 === 0 ? "md:text-right md:pr-8" : "md:text-left md:pl-8"
                  }`}
                >
                  <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6">
                    <div className="flex items-center gap-2 mb-2 justify-start flex-wrap">
                      <Briefcase className="w-4 h-4 text-[#e8634f]" />
                      <span className="text-xs font-medium text-[#e8634f] uppercase tracking-wider">
                        {exp.dates}
                      </span>
                      {exp.type && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-white/10 text-white/70">
                          {exp.type}
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-1">
                      {exp.role}
                    </h3>
                    <p className="text-sm text-[#f4a4a0] font-medium mb-3">
                      {exp.company}
                    </p>
                    <ul className="space-y-1.5 text-left">
                      {exp.description.map((item, i) => (
                        <li
                          key={i}
                          className="text-sm text-white/60 leading-relaxed"
                        >
                          • {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}